const { request, response } = require('express');
const bcrypt = require('bcryptjs');

const { generateJWT } = require('../helpers/generate-jwt');
const User = require('../models/user');

const login = async (req = request, res = response) => {

    const {email, password} = req.body

    try {
        const user = await User.findOne({email});
        if (!user) {
            return res.status(400).json({
                msg: 'User / Password no existen'
            });
        }

        const validatePassword = bcrypt.compareSync(password, user.password);
        if (!validatePassword) {
            return res.status(400).json({
                msg: 'User / Password no son correctos'
            })
        }

        const token = await generateJWT(user.id);

        res.json({
            msg: 'Login Path',
            email, password,
            token
        })
    } catch (error) {
        console.log(error);
        res.status(500).json({
            msg: 'Hable con el administrador'
        })
    }

}

const register = async (req = request, res = response) => {
    const { name, email, password, lastname, phone} = req.body;

    try {
        let user = await User.findOne({ email });
        if (user) {
            return res.status(400).json({
                msg: 'El usuario ya está registrado'
            });
        }

        user = new User(req.body);

        const salt = bcrypt.genSaltSync();
        user.password = bcrypt.hashSync(password, salt);

        const token = await generateJWT(user.id);

        await user.save();

        res.json({
            msg: 'Registro exitoso',
            user,
            token
        });

    } catch (error) {
        console.log(error);
        res.status(500).json({
            msg: 'Hable con el administrador'
        });
    }
}

module.exports = {
    login,
    register
}