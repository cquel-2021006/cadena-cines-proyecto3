const { response, request } = require('express');

const Function = require('../models/function');

const getFunct = async (req = request, res = response) => {
    try {
        const funcList = await Function.find();
        res.status(200).json(funcList);
    } catch (error) {
        res.status(500).json({ error: 'Error en el servidor', error });
    }
}


const postFunct = async (req, res) => {
    const { date } = req.body;

    try {
        const functDB = new Function({ date });

        await functDB.save();

        res.json({
            msg: 'funcion registrada correctamente',
            functDB
        });
    } catch (error) {
        console.log(error);
        res.status(500).json({
            msg: 'Error al registrar la funcion'
        });
    }
};


const deleteFunc = async (req = request, res = response) => {
    const {id} = req.params;

    const funcDelete = await Function.findByIdAndDelete(id);

    res.json({
        msg: "Delete Api - Delete function",
        funcDelete
    })
}


module.exports = {
    getFunct,
    postFunct,
    deleteFunc
}