const { response, request } = require('express');

const Movie = require('../models/movie');

const getMovie = async (req = request, res = response) => {
    try {
        const movieList = await Movie.find();
        res.status(200).json(movieList);
    } catch (error) {
        res.status(500).json({ error: 'Error en el servidor', error });
    }
}

const getMovieById = async (req = request, res = response) => {
    try {
        const id = req.params.id; 
        const movie = await Movie.findById(id); 
        if (!movie) {
            res.status(404).json({ error: 'Película no encontrada' });
        } else {
            res.status(200).json(movie);
        }
    } catch (error) {
        res.status(500).json({ error: 'Error en el servidor', error });
    }
}


const postMovie = async (req, res) => {
    const { title, img, clas, functs } = req.body;

    try {

        const movieDB = new Movie({ title, img, clas, functs });

        await movieDB.save();

        res.json({
            msg: 'Pelicula registrada correctamente',
            movieDB
        });
    } catch (error) {
        console.log(error);
        res.status(500).json({
            msg: 'Error al registrar la pelicula'
        });
    }
};

const putMovie = async (req = request, res = response) => {
    const {id} = req.params;
    const {_id, ...resto} = req.body;

    const movieEdit = await Movie.findByIdAndUpdate(id, resto, {new: true});

    res.json({
        msg: 'Put Api - Put Movie',
        movieEdit
    })
}

const deleteMovie = async (req = request, res = response) => {
    const {id} = req.params;

    const movieDelete = await Movie.findByIdAndDelete(id);

    res.json({
        msg: "Delete Api - Delete Movie",
        movieDelete
    })
}

module.exports = {
    getMovie,
    getMovieById,
    postMovie,
    putMovie,
    deleteMovie
}