const { response, request } = require('express');

const Ticket = require('../models/ticket');

const getTicket = async (req = request, res = response) => {
    try {
        const ticketList = await Ticket.find();
        res.status(200).json(ticketList);
    } catch (error) {
        res.status(500).json({ error: 'Error en el servidor', error });
    }
}

const postTicket = async (req, res) => {
    const { movie, seat} = req.body;

    try {
        const ticketDb = new Ticket({ movie, seat });

        await ticketDb.save();

        res.json({
            msg: 'ticket registrado correctamente',
            ticketDb
        });
    } catch (error) {
        console.log(error);
        res.status(500).json({
            msg: 'Error al registrar el ticket'
        });
    }
};

const deleteTicket = async (req = request, res = response) => {
    const {id} = req.params;

    const ticketDelete = await Ticket.findByIdAndDelete(id);

    res.json({
        msg: "Delete Api - Delete Ticket",
        ticketDelete
    })
}


module.exports = {
    getTicket,
    postTicket,
    deleteTicket
}