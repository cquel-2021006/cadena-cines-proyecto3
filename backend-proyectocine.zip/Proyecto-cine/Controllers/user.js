const { response, request } = require('express');
const bcrypt = require('bcryptjs');

const User = require('../models/user');

const getUser = async (req = request, res = response) => {
    try {
        const userList = await User.find();
        res.status(200).json(userList);
    } catch (error) {
        res.status(500).json({ error: 'Error en el servidor', error });
    }
}

const postUser = async (req, res) => {
    const { name, lastname, password, email, phone, ticket } = req.body;

    try {
        const salt = bcrypt.genSaltSync(10);
        const hashedPassword = bcrypt.hashSync(password, salt);

        const userDB = new User({ name, lastname, password: hashedPassword, email, phone, ticket });

        await userDB.save();

        res.json({
            msg: 'Usuario registrado correctamente',
            userDB
        });
    } catch (error) {
        console.log(error);
        res.status(500).json({
            msg: 'Error al registrar usuario'
        });
    }
};

const putUser = async (req = request, res = response) => {
    const {id} = req.params;
    const {_id, estado, ...resto} = req.body;

    const userEdit = await User.findByIdAndUpdate(id, resto, {new: true});

    res.json({
        msg: 'Put Api - Put User',
        userEdit
    })
}

const deleteUser = async (req = request, res = response) => {
    const {id} = req.params;

    const userDelete = await User.findByIdAndDelete(id);

    res.json({
        msg: "Delete Api - Delete User",
        userDelete
    })
}


module.exports = {
    getUser,
    postUser,
    putUser,
    deleteUser
}