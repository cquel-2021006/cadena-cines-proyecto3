const User = require('../models/user');
const Functs = require('../models/function');
const Ticket = require('../models/ticket');
const Movie = require('../models/movie');
const ticket = require('../models/ticket');

const emailExist = async(email='') => {
    const exist = await User.findOne({email});

    if (exist) {
        throw new Error(`El correo ${email} ya existe y esta registrado en la base de datos`)
    }
}

const movieExist = async(title='') => {
  const exist = await Movie.findOne({title});

  if (exist) {
      throw new Error(`La pelicula ${title} ya existe y esta registrado en la base de datos`)
  }
}

const UserById = async(id) =>{
    const existUser = await User.findById(id)
    
    if (!existUser) {
        throw new Error(`El Id ${id} no existe en la DB`)
    }
}

const MovieById = async(id) =>{
  const existMovie = await Movie.findById(id)
  
  if (!existMovie) {
      throw new Error(`El Id ${id} no existe en la DB`)
  }
}

const ticketById = async(id) =>{
  const existTicket = await Ticket.findById(id)
  
  if (!existTicket) {
      throw new Error(`El Id ${id} no existe en la DB`)
  }
}

const FunctionById = async(id) =>{
  const existfunct = await Functs.findById(id)
  
  if (!existfunct) {
      throw new Error(`El Id ${id} no existe en la DB`)
  }
}


const validateSeat = async(seat='') => {
  const exist = await Ticket.findOne({seat});

  if (exist) {
      throw new Error(`El asiento ${seat} ya fue tomado`)
  }
}
  


module.exports = {
    emailExist,
    movieExist,
    UserById,
    FunctionById,
    MovieById,
    ticketById,
    validateSeat
}