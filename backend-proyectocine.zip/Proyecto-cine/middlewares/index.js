const validateRow = require('../middlewares/validate-row');
const validateJWT = require('../middlewares/validate-jwt');


module.exports = {
    ...validateRow,
    ...validateJWT
}