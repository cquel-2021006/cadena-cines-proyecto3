const {Schema, model} = require('mongoose')

const FunctionSchema = Schema({
    date: Date
})

module.exports = model('Function', FunctionSchema);