const { Schema, model } = require('mongoose')

const MovieSchema = Schema({
    title: {
        type: String,
        required: [true, 'El titulo de la pelicula es obligatorio']
    },
    img: {
        type: String,
        required: true
    },
    clas: {
        type: String,
        required: true
    },
    functs: [{
        type: Schema.Types.ObjectId,
        ref: 'Function',
        default: []
    }]
})

module.exports = model('Movie', MovieSchema);