const express = require('express');
const cors = require('cors');
const { dbConection } = require('../database/config');

class server {

    constructor() {
        this.app = express();
        this.port = process.env.PORT;

        this.paths = {
            auth: '/api/auth',
            function: '/api/function',
            movie: '/api/movie',
            ticket: '/api/ticket',
            user: '/api/user',
        }

        this.conectarDB();

        this.middlewares();

        this.routes();

    }

    async conectarDB() {
        await dbConection();
    }

    middlewares(){
        this.app.use(cors());

        this.app.use(express.json());

        this.app.use(express.static('public'));
    }

    routes(){
        this.app.use(this.paths.auth , require('../routes/auth'));
        this.app.use(this.paths.function, require('../routes/function'));
        this.app.use(this.paths.movie, require('../routes/movie'));
        this.app.use(this.paths.ticket, require('../routes/ticket'));
        this.app.use(this.paths.user, require('../routes/user'));
    }

    listen() {
        this.app.listen(this.port, () => {
            console.log('Servidor Corriendo en puerto ', this.port);
        })
    }

}

module.exports = server;