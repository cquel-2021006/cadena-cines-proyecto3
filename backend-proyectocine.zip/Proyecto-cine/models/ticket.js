const { Schema, model } = require('mongoose');

const TicketSchema = Schema({
    movie: {
        type: Schema.Types.ObjectId,
        ref: 'Movie',
        default: []   
    },
    seat: {
        type: String,
        required: true
    },
})

module.exports = model('Ticket', TicketSchema)