const { Schema, model } = require('mongoose');

const UserSchema = Schema({
    name: {
        type: String,
        require: [true, 'El nombre es obligatorio']
    },
    lastname: {
        type: String,
        require: [true, 'El apellidoe es obligatorio']
    },
    password: {
        type: String,
        require: [true, 'La Contraseña es obligatoria']
    },
    email: {
        type: String,
        require: [true, 'El correo es obligatorio']
    },
    phone: {
        type: String,
        require: [true, 'El telefono es obligatorio']
    },
    estado: {
        type: Boolean,
        default: true
    },
    ticket: [{
        type: Schema.Types.ObjectId,
        ref: 'Ticket',
        default: []
    }]
    
});

module.exports = model('User', UserSchema);
