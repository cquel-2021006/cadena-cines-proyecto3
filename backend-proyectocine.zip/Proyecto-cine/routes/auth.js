const {Router} = require('express');
const {check} = require('express-validator');
const { validateRow } = require('../middlewares');
const { login, register } = require('../Controllers/auth');


const router = Router();

router.post('/login', [
    check('email', 'El correo no es valido').isEmail(),
    check('password', 'El correo no es valido').not().isEmpty(),
    validateRow,
], login)

router.post('/register', [
    check('email', 'El correo no es valido').isEmail(),
    check('password', 'la contraseña no es valido').not().isEmpty(),
    check('name', 'El nombre no es valido').not().isEmpty(),
    check('lastname', 'El apellido no es valido').not().isEmpty(),
    check('phone', 'El telefono no es valido').not().isEmpty(),
    validateRow,
], register)

module.exports = router