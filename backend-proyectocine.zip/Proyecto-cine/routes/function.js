const { Router } = require('express');
const { check } = require('express-validator');
const { getFunct, postFunct, deleteFunc } = require('../Controllers/function');
const { validateRow } = require('../middlewares');
const { FunctionById } = require('../helpers');


const router = Router();

router.get('/get', getFunct);

router.post('/post', [
    check('date', 'la fecha es obligatoria').not().isEmpty(),
    validateRow,
], postFunct);

router.delete('/delete/:id', [
    check('id', 'No es un ID valido').isMongoId(),
    check('id').custom( FunctionById ),
    validateRow
], deleteFunc)


module.exports = router