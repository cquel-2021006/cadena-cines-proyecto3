const { Router } = require('express');
const { check } = require('express-validator');
const { getMovie, postMovie, putMovie, deleteMovie } = require('../Controllers/movie');
const { movieExist, MovieById } = require('../helpers');
const { validateRow, validateJWT } = require('../middlewares');

const router = Router();

router.get('/get', getMovie);

router.post('/post', [
    check('title', 'El nombre es obligatorio').not().isEmpty(),
    check('img', 'La imagen es obligatoria').not().isEmpty(),
    check('clas', 'La clasificacion es obligatorio').not().isEmpty(),
    check('functs', 'La funcion es obligatoria').not().isEmpty(),
    // check('title').custom( movieExist ),
    validateRow,
], postMovie);


router.put('/put/:id', [
    check('id', 'No es un Id Valido').isMongoId(),
    check('id').custom( MovieById ),
    validateRow
], putMovie)


router.delete('/delete/:id', [
    validateJWT,
    check('id', 'No es un ID valido').isMongoId(),
    check('id').custom( MovieById ),
    validateRow
], deleteMovie)


module.exports = router