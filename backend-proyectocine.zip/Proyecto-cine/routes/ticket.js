const { Router } = require('express');
const { check } = require('express-validator');
const { getTicket, postTicket, deleteTicket } = require('../Controllers/ticket');
const { ticketById, validateSeat } = require('../helpers');
const { validateRow } = require('../middlewares');

const router = Router();

router.get('/get', getTicket);

router.post('/post', [
    check('movie', 'El id de pelicula es obligatorio').not().isEmpty(),
    check('seat', 'El asiento obligatorio').not().isEmpty(),
    check('funct', 'La funcion es obligatoria').not().isEmpty(),
    check('seat').custom( validateSeat),
    validateRow,
], postTicket);


router.delete('/delete/:id', [
    check('id', 'No es un ID valido').isMongoId(),
    check('id').custom( ticketById ),
    validateRow
], deleteTicket)

module.exports = router