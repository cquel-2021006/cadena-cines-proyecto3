const { Router } = require('express');
const { check } = require('express-validator');
const { getUser, postUser, putUser, deleteUser, getUserById } = require('../Controllers/user');

const { emailExist, UserById, ticketExist } = require('../helpers');
const { validateRow, validateJWT } = require('../middlewares');

const router = Router();

router.get('/get', getUser);

router.get('/get/:id', getUserById);

router.post('/post', [
    check('name', 'El nombre es obligatorio').not().isEmpty(),
    check('lastname', 'El apellido es obligatorio').not().isEmpty(),
    check('password', 'La contraseña es obligatorio').not().isEmpty(),
    check('email', 'El email es obligatorio').not().isEmpty(),
    check('phone', 'El telefono es obligatorio').not().isEmpty(),
    check('email').custom( emailExist ),
    validateRow,
], postUser);


router.put('/put/:id', [
    check('id', 'No es un Id Valido').isMongoId(),
    check('id').custom( UserById ),
    validateRow
], putUser)


router.delete('/delete/:id', [
    validateJWT,
    check('id', 'No es un ID valido').isMongoId(),
    check('id').custom( UserById ),
    validateRow
], deleteUser)

module.exports = router;